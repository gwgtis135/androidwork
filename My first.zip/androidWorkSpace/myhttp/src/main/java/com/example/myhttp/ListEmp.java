package com.example.myhttp;

import java.util.List;

public class ListEmp {
    List<EmpVO> data;

}
